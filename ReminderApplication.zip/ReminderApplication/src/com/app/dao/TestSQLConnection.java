package com.app.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class TestSQLConnection {
	static String connectionString = "jdbc:mysql://localhost:3306/Sample";
	static String user = "root";
	static String password = "souparnika";
	/*public static void main(String[] args) {
		
		try {
			Connection conn = DriverManager.getConnection(connectionString, user, password);
			String sql = "insert into test(name,score) values(?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, "jeevan");
			stmt.setInt(2, 33);
			int result = stmt.executeUpdate();
			if(result>0){
				System.out.println("success");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}*/
	public boolean insertTest(){
		try {
			Connection conn = DriverManager.getConnection(connectionString, user, password);
			String sql = "insert into test(name,score) values(?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, "jeevan");
			stmt.setInt(2, 33);
			int result = stmt.executeUpdate();
			if(result>0){
				return true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return false;
	}

}
