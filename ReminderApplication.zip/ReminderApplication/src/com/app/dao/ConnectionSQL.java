package com.app.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.app.dto.User;

public class ConnectionSQL {

	private String connectionString = "jdbc:mysql://localhost:3306/sample";
	private String username = "root";
	private String pwd = "souparnika";
	private Connection conn = null;

//	public Connection getSQLConnection() {
//
//		try {
//			conn = DriverManager.getConnection(connectionString, user, password);
//		} catch(SQLException e){
//			System.out.println("SQL Exception!!!");
//			e.printStackTrace();
//		}
//		return conn;
//	}

	public boolean validateUser(String userId, String password) {
		try {
			conn = DriverManager.getConnection(connectionString, username, pwd);
			String query = "SELECT userId,password FROM user "
					+ "where userId=" + userId + " and password =" + password;
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return false;
	}
	
	public boolean registerUser(User user){
		try {
			conn = DriverManager.getConnection(connectionString, username, pwd);
			System.out.println(conn.toString());
			String query = "insert into user(name,emailId,userId,password,DOB) values(?,?,?,?,?)";
			System.out.println(user.toString());
			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, user.getName());
			pstmt.setString(2, user.getEmailId());
			pstmt.setString(3, user.getUserId());
			pstmt.setString(4, user.getPassword());
			pstmt.setDate(5, Date.valueOf(user.getDateOfBirth()));
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

}
