package com.app.services;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.dao.ConnectionSQL;
import com.app.dao.TestSQLConnection;
import com.app.dto.User;

/**
 * Servlet implementation class RegisterUser
 */
@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User user = new User();
		user.setName(request.getParameter("name"));
		user.setEmailId(request.getParameter("emailId"));
		user.setUserId(request.getParameter("userId"));
		user.setPassword(request.getParameter("password"));
		String setDateOfBirth =request.getParameter("dateOfBirth");
		System.out.println(setDateOfBirth);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		user.setDateOfBirth(LocalDate.parse(setDateOfBirth, formatter));
		//ConnectionSQL register = new ConnectionSQL();
		TestSQLConnection test = new TestSQLConnection();
		/*if(register.registerUser(user)){
			request.setAttribute("name", user.getName());
			RequestDispatcher rd = request.getRequestDispatcher("/Welcome.jsp");
			rd.forward(request, response);
		}*/
		if(test.insertTest()){
			request.setAttribute("name", user.getName());
			RequestDispatcher rd = request.getRequestDispatcher("/Welcome.jsp");
			rd.forward(request, response);
		}
		else{
			RequestDispatcher rd = request.getRequestDispatcher("/Error.jsp");
			rd.forward(request, response);
		}
		
	}

}
