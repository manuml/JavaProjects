package com.app.dto;

import java.time.LocalDate;
import java.util.List;

public class User {
	@Override
	public String toString() {
		return "User [name=" + name + ", emailId=" + emailId + ", userId="
				+ userId + ", password=" + password + ", dateOfBirth="
				+ dateOfBirth + ", reminders=" + reminders + "]";
	}
	private String name;
	private String emailId;
	private String userId;
	private String password;
	private LocalDate dateOfBirth;
	private List<String> reminders;
	public User(){}
	public User(String name,String emailId,String password,LocalDate dateOfBirth){
		this.name=name;
		this.emailId = emailId;
		this.password = password;
		this.dateOfBirth= dateOfBirth;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public List<String> getReminders() {
		return reminders;
	}
	public void setReminders(List<String> reminders) {
		this.reminders = reminders;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	

}
